﻿using AIN.PAAS.SQL.Models.Models;
using AIN.PAAS.SQL.Models.Models.Request;
using AIN.PAAS.SQL.Models.Models.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AIN.PAAS.SQL.Services.IServices
{
   public interface IInventoryServices
    {
        Task<InventoryResponse> GetInventoryDetailsById(Guid inventoryId);
        Task<CheckInResponse> InventoryCheckIn(CheckInRequest checkInRequest);
        Task<List<InventoryResponse>> GetInventoryByStatus(string status);
        Task<InventoryItem> InventoryCheckOut(CheckOutRequest checkOutRequest);
        Task<TransferRequestData> ItemTransfer(TransferRequestData transferRequestData);
    }
}
