﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AIN.PAAS.SQL.Models.Models
{
   public class DatabaseSettings
    {
        public string Database { get; set; }

    }
}
