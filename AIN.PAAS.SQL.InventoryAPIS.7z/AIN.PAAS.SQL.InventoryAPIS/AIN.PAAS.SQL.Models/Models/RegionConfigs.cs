﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AIN.PAAS.SQL.Models.Models
{
    public class RegionConfigs
    {
        public string APIDomain { get; set; }
    }
}
